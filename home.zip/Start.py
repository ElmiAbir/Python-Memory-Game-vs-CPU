import time  # Import the time module for sleep function

# List of strings representing the introduction ASCII art
Intro_Lines = [
    "                      __       __                                                               ______                                    ",
    "                     /  \\     /  |                                                             /      \\                                   ",
    "                     MM  \\   /MM |  ______   _____  ____    ______    ______   __    __       /GGGGGG  |  ______   _____  ____    ______  ",
    "                     MMM  \\ /MMM | /      \\ /     \\/    \\  /      \\  /      \\ /  |  /  |      GG | _GG/  /      \\ /     \\/    \\  /      \\ ",
    "                     MMMM  /MMMM |/eeeeee  |mmmmmm mmmm  |/oooooo  |/rrrrrr  |yy |  yy |      GG |/    | aaaaaa  |mmmmmm mmmm  |/eeeeee  |",
    "                     MM MM MM/MM |ee    ee |mm | mm | mm |oo |  oo |rr |  rr/ yy |  yy |      GG |GGGG | /    aa |mm | mm | mm |ee    ee |",
    "                     MM |MMM/ MM |eeeeeeee/ mm | mm | mm |oo \\__oo |rr |      yy \\__yy |      GG \\__GG |/aaaaaa$ |mm | mm | mm |eeeeeeee/ ",
    "                     MM | M/  MM |ee       |mm | mm | mm |oo    oo/ rr |      yy    yy |      GG    GG/ aa    aa |mm | mm | mm |ee _ _ _  ",
    "                     MM/      MM/  eeeeeee/ mm/  mm/  mm/  oooooo/  rr/        yyyyyyy |       GGGGGG/   aaaaaaa/ mm/  mm/  mm/  eeeeeee/ ",
    "                                                                              /  \\__yy |                                                  ",
    "                                                                              yy    yy/                                                   ",
    "                                                                               yyyyyy/                                                    "
]

# Print each line of the introduction art with a slight delay
for line in Intro_Lines:
    print(line)
    time.sleep(0.07)  # Pause for 0.07 seconds between each line

print("")  # Print a blank line for spacing

# Print the game title and instructions in ASCII art
print(r"                                ___ ____ __ ___ ____   ___ _  _ ___ ___ ____   ___ ____   ____ _  ____ _   _")
print(r"                                |__]|__/|__ [__ [__    |__ |\ |  |  |__ |__/    |  |  |   |__] |  |__|  \_/ ")
print(r"                                |   |  \|__ ___] __]   |__ | \|  |  |__ |  \    |  |__|   |    |__|  |   |  ")

# Wait for user input to start the game
Start_Game = input("")
import DifficultySelector  # Active the difficulty selection file

