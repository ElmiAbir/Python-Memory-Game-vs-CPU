﻿Group Members:
1) Ren Xuxiang
2) Mohammed Elmi Shah Abir
3) Chen ruihan
4) Cai Chun Ho
5) Su Man Lok Adrian
Game Name: Memory Game vs CPU
Demo Link: https://youtu.be/Jl2B8WNUQIk
Trailer Link: https://youtu.be/HLrO2b1e-Fk
About Game:
Welcome to the Memory Game vs CPU! This guide will walk you through everything you need to know to start playing.
Game Objective
The goal of the Memory Game is to match all pairs (in Easy mode) or triples (in Hard mode) of cards before the CPU does. The one(CPU or Player) who matches all their cards first wins!
Game Setup
1. Starting the Game:
   * Upload the zip file 'MemoryGame.zip' onto an Ed workspace
   * Select upload and extract
   * Play the game on full screen of Ed. Drag the Terminal to full screen mode.
   * Click the terminal icon ('>_') on the top right corner of the web page.
   * Type "python Start.py" in the same line as [user@sahara] to begin playing the game.
   * The game starts with "Memory Game" and "Press Enter to Play" ASCII arts followed by a difficulty selection.
   * You'll be prompted to choose the difficulty level: 
      * Type 1 for Easy Mode.
      * Type 2 for Hard Mode.
2. Difficulty Levels:
   * Easy Mode: You need to match pairs of cards.
   * Hard Mode: You need to match triples of cards.
Playing the Game
1. Game Board:
   * The game board consists of a grid of cards, each labeled with indices (e.g., 00, 01, 12 etc.). The left board is for the Player, the right is for the CPU.
   * Cards start face down and are revealed by their indices when selected.
2. Your Turn:
   * Easy Mode: Select two cards to reveal by typing their indices (e.g., 0 1), separated by space.
   * Hard Mode: Select three cards to reveal by typing their indices (e.g., 0 1 2), separated by space.
   * If the selected cards match, they will be marked as XX and remain face up.
   * If they do not match, they will be turned face down again.
3. CPU Turn:
   * The CPU will also select cards in an attempt to find matches.
   * The CPU's choices will be displayed, and it will follow the same matching rules.
4. Winning the Game:
   * The game continues until the player or CPU matches all their cards.
   * If you match all your cards first, you win! The CPU will congratulate you by printing a sentence.
   * If the CPU matches all its cards first, the CPU wins and a follow up sentence is printed 
   * A “Game Over” ASCII art is printed.
Rules
* You cannot select the same card twice in one turn.
* You must choose cards within the valid index range.
* Invalid inputs will prompt you to try again.
Tips
* Pay attention to the cards revealed by both you and the CPU.
* Try to remember the positions of your cards to make strategic matches.
Enjoy the game and test your memory skills against the CPU!


Reference List:
Text to ASCII Art Generator (TAAG). (n.d.). https://patorjk.com/software/taag/#p=display&f=Graffiti&t=Type%20Something%20
Poe. (n.d.). Poe - Fast, helpful AI chat. Retrieved November 12, 2024, from https://poe.com/