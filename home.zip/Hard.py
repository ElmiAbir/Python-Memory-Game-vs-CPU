import random
import sys

# Global variables to hold the CPU state and card information, CPUKnows is to keep track of which cards the CPU remembers, while CPUList is the 'memory'
global CPUSet
global CPUIndex
global CPUList
global CPUDict
global CPUKnows

# Function to print the Game Over text
def GameOver_print():
    print(r"  ______                                            ______                                ")              
    print(r" /      \                                          /      \                               ")         
    print(r"/GGGGGG  |  ______   _____  ____    ______        /OOOOOO  | __     __  ______    ______  ")
    print(r"GG | _GG/  /      \ /     \/    \  /      \       OO |  OO |/  \   /  |/      \  /      \ ")
    print(r"GG |/    | aaaaaa  |mmmmmm mmmm  |/eeeeee  |      OO |  OO |vv  \ /vv//eeeeee  |/rrrrrr  |")
    print(r"GG |GGGG | /    aa |mm | mm | mm |ee    ee |      OO |  OO | vv  /vv/ ee    ee |rr |  rr/ ")
    print(r"GG \__GG |/aaaaaaa |mm | mm | mm |eeeeeeee/       OO \__OO |  vv vv/  eeeeeeee/ rr |      ")
    print(r"GG    GG/ aa    aa |mm | mm | mm |ee       |      OO    OO/    vvv/   ee       |rr |      ")
    print(r" GGGGGG/   aaaaaaa/ mm/  mm/  mm/  eeeeeee/        OOOOOO/      v/     eeeeeee/ rr/       ")
                                                        
# Function to print the player and CPU card sets for the hard mode
def HardPlayer_print(PlayerSetHard, CPUIndex):
    # Print the player's and CPU's current card states in a formatted way
    print(
        f'| {PlayerSetHard[0]} |   | {PlayerSetHard[1]} |   | {PlayerSetHard[2]} |   | {PlayerSetHard[3]} |   | {PlayerSetHard[4]} |   | {PlayerSetHard[5]} |    ||    | {CPUIndex[0]} |   | {CPUIndex[1]} |   | {CPUIndex[2]} |   | {CPUIndex[3]} |   | {CPUIndex[4]} |   | {CPUIndex[5]} |')
    print(
        f'| {PlayerSetHard[6]} |   | {PlayerSetHard[7]} |   | {PlayerSetHard[8]} |   | {PlayerSetHard[9]} |   | {PlayerSetHard[10]} |   | {PlayerSetHard[11]} |    ||    | {CPUIndex[6]} |   | {CPUIndex[7]} |   | {CPUIndex[8]} |   | {CPUIndex[9]} |   | {CPUIndex[10]} |   | {CPUIndex[11]} |')
    print(
        f'| {PlayerSetHard[12]} |   | {PlayerSetHard[13]} |   | {PlayerSetHard[14]} |   | {PlayerSetHard[15]} |   | {PlayerSetHard[16]} |   | {PlayerSetHard[17]} |    ||    | {CPUIndex[12]} |   | {CPUIndex[13]} |   | {CPUIndex[14]} |   | {CPUIndex[15]} |   | {CPUIndex[16]} |   | {CPUIndex[17]} |')
    print(
        f'| {PlayerSetHard[18]} |   | {PlayerSetHard[19]} |   | {PlayerSetHard[20]} |   | {PlayerSetHard[21]} |   | {PlayerSetHard[22]} |   | {PlayerSetHard[23]} |    ||    | {CPUIndex[18]} |   | {CPUIndex[19]} |   | {CPUIndex[20]} |   | {CPUIndex[21]} |   | {CPUIndex[22]} |   | {CPUIndex[23]} |')


# Function for the CPU's random card selection (CPU can't remember a pair/triple)
def CPURandom():
    Picked2nd = False  # Flag to check if a matching card has been picked
    ChosenList = []  # List to hold the chosen card indices
    CPUCard1 = random.randint(0, 23)  # Pick a random index for the first card
    # Ensure the chosen index is not already matched or known
    while CPUIndex[CPUCard1] == 'XX' or CPUCard1 in CPUKnows:
        CPUCard1 = random.randint(0, 23)
    ChosenList.append(CPUCard1)  # Add the first card to the chosen list

    # If this card is new or the CPU has no known cards, add it to CPUList and CPUKnows
    if CPUCard1 not in CPUKnows or len(CPUList) == 0:
        CPUList.append([CPUCard1, CPUSet[CPUCard1]])
        CPUKnows.append(CPUCard1)

    # If only one card is in the CPUList, pick two more random cards
    if len(CPUList) == 1:
        CPUCard2 = random.randint(0, 23)
        while CPUIndex[CPUCard2] == 'XX' or CPUCard2 == CPUCard1 or CPUCard2 in CPUKnows:
            CPUCard2 = random.randint(0, 23)
        ChosenList.append(CPUCard2)  # Add the second card

        # Add the second card to CPUList and CPUKnows if not known
        if CPUCard2 not in CPUKnows:
            CPUList.append([CPUCard2, CPUSet[CPUCard2]])
            CPUKnows.append(CPUCard2)

        # Pick a third card randomly
        CPUCard3 = random.randint(0, 23)
        while CPUIndex[CPUCard3] == 'XX' or CPUCard3 == CPUCard1 or CPUCard3 == CPUCard2 or CPUCard3 in CPUKnows:
            CPUCard3 = random.randint(0, 23)
        ChosenList.append(CPUCard3)  # Add the third card

        # Add the third card to CPUList and CPUKnows if not known
        if CPUCard3 not in CPUKnows:
            CPUList.append([CPUCard3, CPUSet[CPUCard3]])
            CPUKnows.append(CPUCard3)
        return ChosenList

    # If the CPU already has a card, try to find a matching card
    else:
        for i in range(len(CPUList)):
            if CPUList[i][1] == CPUSet[CPUCard1] and CPUCard1 != CPUList[i][0] and not Picked2nd:
                CPUCard2 = CPUList[i][0]  # Select the matching card
                ChosenList.append(CPUCard2)
                Picked2nd = True

        # If a match has been found, pick another random card
        if Picked2nd:
            CPUCard3 = random.randint(0, 23)
            while CPUIndex[CPUCard3] == 'XX' or CPUCard3 == CPUCard1 or CPUCard3 == CPUCard2 or CPUCard3 in CPUKnows:
                CPUCard3 = random.randint(0, 23)
            ChosenList.append(CPUCard3)  # Add the third card

            # Add the third card to CPUList and CPUKnows if not known
            if CPUCard3 not in CPUKnows:
                CPUList.append([CPUCard3, CPUSet[CPUCard3]])
                CPUKnows.append(CPUCard3)
            return ChosenList
        # If no match was found, select two random cards
        else:
            CPUCard2 = random.randint(0, 23)
            while CPUIndex[CPUCard2] == 'XX' or CPUCard2 == CPUCard1 or CPUCard2 in CPUKnows:
                CPUCard2 = random.randint(0, 23)
            ChosenList.append(CPUCard2)  # Add the second card

            # Add the second card to CPUList and CPUKnows if not known
            if CPUCard2 not in CPUKnows:
                CPUList.append([CPUCard2, CPUSet[CPUCard2]])
                CPUKnows.append(CPUCard2)

            # Pick a third card randomly
            CPUCard3 = random.randint(0, 23)
            while CPUIndex[CPUCard3] == 'XX' or CPUCard3 == CPUCard1 or CPUCard3 == CPUCard2 or CPUCard3 in CPUKnows:
                CPUCard3 = random.randint(0, 23)
            ChosenList.append(CPUCard3)  # Add the third card

            # Add the third card to CPUList and CPUKnows if not known
            if CPUCard3 not in CPUKnows:
                CPUList.append([CPUCard3, CPUSet[CPUCard3]])
                CPUKnows.append(CPUCard3)
            return ChosenList


# Function to find triples known to CPU
def CPUTriples():
    ChosenList = []
    Pickedtriples = False  # Flag to check if triples have been picked
    for x in CPUDict:
        if CPUDict[x] == 3 and CPUIndex[CPUSet.index(x)] != 'XX' and not Pickedtriples:
            Picked = x  # Found a triple
            Pickedtriples = True
    # Return the indices of the cards that form the triple
    ChosenList = [x[0] for x in CPUList if x[1] == Picked]
    return ChosenList


# Function to find pairs known to CPU
def CPUPairs():
    ChosenList = []
    Pickedpairs = False  # Flag to check if pairs have been picked
    for x in CPUDict:
        if CPUDict[x] == 2 and CPUIndex[CPUSet.index(x)] != 'XX' and not Pickedpairs:
            Picked = x  # Found a pair
            Pickedpairs = True
    # Return the indices of the cards that form the pair
    ChosenList = [x[0] for x in CPUList if x[1] == Picked]

    # Pick a random card if pairs were found
    CPUCard3 = random.randint(0, 23)
    while CPUIndex[CPUCard3] == 'XX' or CPUCard3 in ChosenList or CPUCard3 in CPUKnows:
        CPUCard3 = random.randint(0, 23)
    ChosenList.append(CPUCard3)  # Add the third card

    # Add the third card to CPUList and CPUKnows if not known
    if CPUCard3 not in CPUKnows:
        CPUList.append([CPUCard3, CPUSet[CPUCard3]])
        CPUKnows.append(CPUCard3)

    return ChosenList


# Game setup
space = "-" * 120  # Separator line for printing
HardPlayerSet = ['AA', 'AA', 'AA', 'BB', 'BB', 'BB', 'CC', 'CC', 'CC', 'DD', 'DD', 'DD', 'EE', 'EE', 'EE', 'FF', 'FF',
                 'FF', 'GG', 'GG', 'GG', 'HH', 'HH', 'HH']
HardPlayerIndex = ['00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16',
                   '17', '18', '19', '20', '21', '22', '23']
random.shuffle(HardPlayerSet)  # Shuffle player cards
CPUSet = ['AA', 'AA', 'AA', 'BB', 'BB', 'BB', 'CC', 'CC', 'CC', 'DD', 'DD', 'DD', 'EE', 'EE', 'EE', 'FF', 'FF', 'FF',
          'GG', 'GG', 'GG', 'HH', 'HH', 'HH']
CPUIndex = ['00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17',
            '18', '19', '20', '21', '22', '23']
random.shuffle(CPUSet)  # Shuffle CPU cards
CPUList = []  # List to hold the CPU's known cards
CPUKnows = []  # List to keep track of indicies of the cards the CPU knows
win = False  # Flag to check if the game is won
turn = False  # Flag to manage the turn
Turncount = 0 # Integer to keep track of number of turns

# Main game loop
while not win:
    # Inputting
    while turn:
        CPUDict = {}  # Dictionary to count pairs and triples known by CPU
        CheckList = []  # List to hold the CPU's card selections
        HvPairs = False  # Flag to check if the CPU has pairs
        HvTriples = False  # Flag to check if the CPU has triples
        Match = True  # Flag to check if the player's cards match
        Invalid = False # Flag to keep track if a player entered a correct input

        # Check if the CPU has already found pairs or triples
        if len(CPUList) >= 1:
            for x in CPUList:
                if x[1] in CPUDict:
                    CPUDict[x[1]] += 1
                else:
                    CPUDict[x[1]] = 1
            # Determine if CPU has triples or pairs
            for x in CPUDict:
                if CPUDict[x] == 3 and CPUIndex[CPUSet.index(x)] != 'XX':
                    HvTriples = True
                elif CPUDict[x] == 2 and CPUIndex[CPUSet.index(x)] != 'XX':
                    HvPairs = True

        # Choose cards based on whether the CPU has triples or pairs
        if HvTriples:
            CheckList = CPUTriples()  # Get known triples
        elif HvPairs and not HvTriples:
            CheckList = CPUPairs()  # Get known pairs
        else:
            CheckList = CPURandom()  # Pick cards randomly

        HardPlayer_print(HardPlayerIndex, CPUIndex)  # Display current state
        while True:
            try:
                print('The CPU picked cards with index:', CheckList)
                print(f"Please select three cards (0 to 23): ")
                a, b, c = map(int, input().split(" "))  # Read player's input
                break
            except ValueError:
                print(f"{space}")
                print(f"Invalid input! Please input 3 choices within the range 0 to 23!")
                print("CPU: I'm giving you pass for this")
                print(f"{space}")
                Invalid = True
                HardPlayer_print(HardPlayerIndex, CPUIndex)  # Display current state again

        print(f"{space}")

        # Validate player input
        if (a not in range(0, len(HardPlayerSet) + 1)) or (b not in range(0, len(HardPlayerSet) + 1)) or (
                c not in range(0, len(HardPlayerSet) + 1)):
            print(f"Please select the numbers in range!")
            print(f"{space}")
            Invalid = True
        elif HardPlayerIndex[a] == "XX" or HardPlayerIndex[b] == "XX" or HardPlayerIndex[c] == "XX":
            print(f"You have already matched one of the items of the selected set. Please select any other set")
            print(f"{space}")
            Invalid = True
        elif a == b or b == c or a == c or a == b == c:
            print(f"Choices cannot be equal!!")
            print(f"{space}")
            Invalid = True
        elif 0 <= a <= len(HardPlayerSet) and 0 <= b <= len(HardPlayerSet) and 0 <= c <= len(HardPlayerSet):
            HardPlayerIndex[a] = HardPlayerSet[a]  # Reveal the player's first card
            HardPlayerIndex[b] = HardPlayerSet[b]  # Reveal the player's second card
            HardPlayerIndex[c] = HardPlayerSet[c]  # Reveal the player's third card

            # Reveal the CPU's selected cards
        for x in CheckList:
            CPUIndex[x] = CPUSet[x]
            MatchTarget = CPUSet[x]
        HardPlayer_print(HardPlayerIndex, CPUIndex)  # Display the updated board

            # Check if the player's cards match
        if Invalid == False and HardPlayerIndex[a] == HardPlayerIndex[b] == HardPlayerIndex[c]:
            HardPlayerIndex[a] = "XX"  # Mark matched cards as 'XX'
            HardPlayerIndex[b] = "XX"
            HardPlayerIndex[c] = "XX"

        elif Invalid == False:
                # Update indices if no match
            if -1 < a < 10:
                HardPlayerIndex[a] = "0" + str(a)
            else:
                HardPlayerIndex[a] = a
            if -1 < b < 10:
                HardPlayerIndex[b] = "0" + str(b)
            else:
                HardPlayerIndex[b] = b
            if -1 < c < 10:
                HardPlayerIndex[c] = "0" + str(c)
            else:
                HardPlayerIndex[c] = c
        print(f"{space}")

        # CPU's turn to process its choices
        for x in CheckList:
            if CPUSet[x] != MatchTarget:
                Match = False  # If no match, set Match to False
        for x in CheckList:
            if Match:  # If a match was found
                CPUIndex[x] = 'XX'  # Mark CPU's chosen cards as 'XX'
            else:
                if x < 10:
                    CPUIndex[x] = ('0' + str(x))  # Format index for display
                else:
                    CPUIndex[x] = str(x)

        if Invalid: # Dialogue for invalid inputs
            Dialogue = random.randint(0, 3)
            if Dialogue == 0:
                print("CPU: Not that hard to type 3 CORRECT inputs right...?")
            elif Dialogue == 1:
                print("CPU: Less than 3 inputs I can tolerate, but THIS??")
            elif Dialogue == 2:
                print("CPU: Try a bit harder, maybe...?")
            elif Dialogue == 3:
                print("CPU:  Well I'll still be taking this turn")
        elif Match and not Invalid: #Dialogue for if the CPU got triple
            Dialogue = random.randint(0, 3)
            if Dialogue == 0:
                print("CPU: Bullseye!!")
            elif Dialogue == 1:
                print("CPU: And that's a bingo!!")
            elif Dialogue == 2:
                print("CPU: Three in a row!!")
            elif Dialogue == 3:
                print("CPU: Flawless!!")
        elif HvPairs and not HvTriples: #Dialogue for if the CPU remembers a pair
            Dialogue = random.randint(0,3)
            if Dialogue == 0:
                print("CPU: Least I remembered 2!!")
            elif Dialogue == 1:
                print("CPU: 2's better than nothing I suppose!!")
            elif Dialogue == 2:
                print("CPU: Glad I remembered those 2!!")
            elif Dialogue == 3:
                print("CPU: Well they came in handy!!")
        elif Turncount <= 15: # Dialogue for start of the game
            Dialogue = random.randint(0,5)
            if Dialogue == 0:
                print("CPU: Did I leave the kettle on...?")
            elif Dialogue == 1:
                print("CPU: Still don't know enough about my cards...")
            elif Dialogue == 2:
                print("CPU: Raring to go!!")
            elif Dialogue == 3:
                print("CPU: Cmon memory work!!")
            elif Dialogue == 4:
                print("CPU: Wonder how Easy Mode's going...")
            elif Dialogue == 5:
                print("CPU: We've only just begun!!")
        else: #Dialogue for when the game's getting long
            Dialogue = random.randint(0,5)
            if Dialogue == 0:
                print("CPU: Did I leave the kettle on...?")
            elif Dialogue == 1:
                print("CPU: Can we wrap this up? I got things to do after...")
            elif Dialogue == 2:
                print("CPU: Will this be over soon...?")
            elif Dialogue == 3:
                print("CPU: I should be working at this time...")
            elif Dialogue == 4:
                print("CPU: Guess this is a long one!!")
            elif Dialogue == 5:
                print("CPU: Still at it!!")
        print(f"{space}")

        Turncount += 1 # Adds 1 to the turn count
        turn = False  # Switch to checking wins

    # Check for win conditions
    while not turn:
        if HardPlayerIndex.count('XX') == len(HardPlayerIndex) and CPUIndex.count('XX') == len(CPUIndex): # For if a draw occurs
            HardPlayer_print(HardPlayerIndex, CPUIndex)
            GameOver_print()
            print("\n                               A draw? Well that's rare...")
            print(f"                                   It took {Turncount} turns for this draw")
        if HardPlayerIndex.count('XX') == len(HardPlayerIndex): # For if the player wins first
            HardPlayer_print(HardPlayerIndex, CPUIndex)
            GameOver_print()
            print("\n                               Congrats, you've defeated me!!")
            print(f"                                   You've taken {Turncount} turns")
            win = True
            sys.exit()  # Exit the game
        elif CPUIndex.count('XX') == len(CPUIndex): # For if the CPU wins first
            HardPlayer_print(HardPlayerIndex, CPUIndex)
            GameOver_print()
            print("\n                               Better luck next time!!")
            print(f"                                   I've defeated you in {Turncount} turns")
            win = True
            sys.exit()  # Exit the game
        turn = True  # Switches back to inputting
