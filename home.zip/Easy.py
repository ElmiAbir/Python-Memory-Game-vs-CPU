import random
import sys

# Global variables to hold the CPU state and card information
global CPUSet
global CPUIndex
global CPUList
global CPUDict
global CPUKnows

# Function to print the Game Over text
def GameOver_print():
    print(r"  ______                                            ______                                ")              
    print(r" /      \                                          /      \                               ")         
    print(r"/GGGGGG  |  ______   _____  ____    ______        /OOOOOO  | __     __  ______    ______  ")
    print(r"GG | _GG/  /      \ /     \/    \  /      \       OO |  OO |/  \   /  |/      \  /      \ ")
    print(r"GG |/    | aaaaaa  |mmmmmm mmmm  |/eeeeee  |      OO |  OO |vv  \ /vv//eeeeee  |/rrrrrr  |")
    print(r"GG |GGGG | /    aa |mm | mm | mm |ee    ee |      OO |  OO | vv  /vv/ ee    ee |rr |  rr/ ")
    print(r"GG \__GG |/aaaaaaa |mm | mm | mm |eeeeeeee/       OO \__OO |  vv vv/  eeeeeeee/ rr |      ")
    print(r"GG    GG/ aa    aa |mm | mm | mm |ee       |      OO    OO/    vvv/   ee       |rr |      ")
    print(r" GGGGGG/   aaaaaaa/ mm/  mm/  mm/  eeeeeee/        OOOOOO/      v/     eeeeeee/ rr/       ")
                                       
# Function to print the player and CPU card sets
def EasyPlayer_print(PlayerSetEasy, CPUIndex):
    # Print the player's and CPU's current card states in a formatted way
    print(
        f'| {PlayerSetEasy[0]} |   | {PlayerSetEasy[1]} |   | {PlayerSetEasy[2]} |   | {PlayerSetEasy[3]} |     ||     | {CPUIndex[0]} |   | {CPUIndex[1]} |   | {CPUIndex[2]} |   | {CPUIndex[3]} |   ')
    print(
        f'| {PlayerSetEasy[4]} |   | {PlayerSetEasy[5]} |   | {PlayerSetEasy[6]} |   | {PlayerSetEasy[7]} |     ||     | {CPUIndex[4]} |   | {CPUIndex[5]} |   | {CPUIndex[6]} |   | {CPUIndex[7]} |   ')
    print(
        f'| {PlayerSetEasy[8]} |   | {PlayerSetEasy[9]} |   | {PlayerSetEasy[10]} |   | {PlayerSetEasy[11]} |     ||     | {CPUIndex[8]} |   | {CPUIndex[9]} |   | {CPUIndex[10]} |   | {CPUIndex[11]} |   ')
    print(
        f'| {PlayerSetEasy[12]} |   | {PlayerSetEasy[13]} |   | {PlayerSetEasy[14]} |   | {PlayerSetEasy[15]} |     ||     | {CPUIndex[12]} |   | {CPUIndex[13]} |   | {CPUIndex[14]} |   | {CPUIndex[15]} |   ')


# Function for the CPU's random card selection
def CPURandom():
    Picked2nd = False  # Flag to check if the second card was picked
    ChosenList = []  # List to hold the chosen card indices
    CPUCard1 = random.randint(0, 15)  # Pick a random index for the first card
    # Ensure the chosen index is not already matched
    while CPUIndex[CPUCard1] == 'XX':
        CPUCard1 = random.randint(0, 15)
    ChosenList.append(CPUCard1)  # Add the first card to the chosen list
    CPUCard2 = random.randint(0, 15)
    while CPUIndex[CPUCard2] == 'XX' or CPUCard2 == CPUCard1:
        CPUCard2 = random.randint(0, 15)
    ChosenList.append(CPUCard2)
    return ChosenList

            

# Game setup
space = "-" * 120  # Separator line for printing
EasyPlayerSet = ['AA', 'AA', 'BB', 'BB', 'CC', 'CC', 'DD', 'DD', 'EE', 'EE', 'FF', 'FF', 'GG', 'GG', 'HH', 'HH']
EasyPlayerIndex = ['00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15']
random.shuffle(EasyPlayerSet)  # Shuffle player cards
CPUSet = ['AA', 'AA', 'BB', 'BB', 'CC', 'CC', 'DD', 'DD', 'EE', 'EE', 'FF', 'FF', 'GG', 'GG', 'HH', 'HH']
CPUIndex = ['00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15']
random.shuffle(CPUSet)  # Shuffle CPU cards
win = False  # Flag to check if the game is won
turn = True  # Flag to manage the turn
Turncount = 0
# Main game loop
while not win:
    # Player's turn
    while turn:
        Match = True  # Flag to check if the player's cards match
        Invalid = False #Flag to keep track if input is valid

        CheckList = CPURandom()  # Pick cards randomly

        # Get the player's card selection
        while True:
            try:
                EasyPlayer_print(EasyPlayerIndex, CPUIndex)  # Display current state
                print('The CPU picked cards with index:', CheckList)
                print(f"Please select two cards (0 to 15): ")
                a, b = map(int, input().split(" "))  # Read player's input
                break
            except ValueError:
                print(f"{space}")
                print(f"Invalid input! Please input 2 choices within the range 0 to 15!")
                print("CPU: You get a pass for this, I guess?")
                print(f"{space}")
                Invalid = True

        print(f"{space}")

        # Validate player input
        if (a not in range(0, len(EasyPlayerSet) + 1)) or (b not in range(0, len(EasyPlayerSet) + 1)):
            print(f"Please select the numbers in range!")
            print(f"{space}")
            Invalid = True
        elif EasyPlayerIndex[a] == "XX" or EasyPlayerIndex[b] == "XX":
            print(f"You have already matched one of the items of the selected set. Please select any other set")
            print(f"{space}")
            Invalid = True
        elif a == b:
            print(f"Choices cannot be equal!!")
            print(f"{space}")
            Invalid = True
        elif 0 <= a <= len(EasyPlayerSet) and 0 <= b <= len(EasyPlayerSet):
            EasyPlayerIndex[a] = EasyPlayerSet[a]  # Reveal the player's first card
            EasyPlayerIndex[b] = EasyPlayerSet[b]  # Reveal the player's second card

        for x in CheckList:
            CPUIndex[x] = CPUSet[x]  # Reveal the CPU's selected cards
            MatchTarget = CPUSet[x]  # Store the target for matching

        EasyPlayer_print(EasyPlayerIndex, CPUIndex)  # Display the updated board

            # Check if the player's cards match
        if Invalid == False and EasyPlayerIndex[a] == EasyPlayerIndex[b]:
            EasyPlayerIndex[a] = "XX"  # Mark matched cards as 'XX'
            EasyPlayerIndex[b] = "XX"

        elif Invalid == False:  # Update indices if no match
            if -1 < a < 10:
                EasyPlayerIndex[a] = "0" + str(a)
            else:
                EasyPlayerIndex[a] = a
            if -1 < b < 10:
                EasyPlayerIndex[b] = "0" + str(b)
            else:
                EasyPlayerIndex[b] = b

        print(f"{space}")

        # CPU's turn to process its choices
        for x in CheckList:
            if CPUSet[x] != MatchTarget:
                Match = False  # If no match, set Match to False
        for x in CheckList:
            if Match:  # If a match was found
                CPUIndex[x] = 'XX'  # Mark CPU's chosen cards as 'XX'
            else:
                if x < 10:
                    CPUIndex[x] = ('0' + str(x))  # Format index for display
                else:
                    CPUIndex[x] = str(x)
        if Invalid: # Dialogue for invalid inputs
            Dialogue = random.randint(0, 3)
            if Dialogue == 0:
                print("CPU: Ummm...I'll be taking my turn...?")
            elif Dialogue == 1:
                print("CPU: Hard Mode told me to only stop for less than 3 inputs, so...")
            elif Dialogue == 2:
                print("CPU: ...Well here I go!!")
            elif Dialogue == 3:
                print("CPU: We're still friends after this right??")
        if Match: #Dialogue for if the CPU remembers a pair
            Dialogue = random.randint(0,3)
            if Dialogue == 0:
                print("CPU: Wow I guessed right??")
            elif Dialogue == 1:
                print("CPU: Luck's on my side!!")
            elif Dialogue == 2:
                print("CPU: Hey I got it!!")
            elif Dialogue == 3:
                print("CPU: Wait till Hard Mode hears about this!!")
        elif Turncount <= 15: # Dialogue for start of the game
            Dialogue = random.randint(0,5)
            if Dialogue == 0:
                print("CPU: I'll do my best!!")
            elif Dialogue == 1:
                print("CPU: I won't be remembering ANYTHING at all!!")
            elif Dialogue == 2:
                print("CPU: My mind's empty but I got spirit!!")
            elif Dialogue == 3:
                print("CPU: Eeny, meeny, miny... moe!!")
            elif Dialogue == 4:
                print("CPU: These two cards look nice, guess I'll pick'em!!")
            elif Dialogue == 5:
                print("CPU: The game is afoot!!")
        else: #Dialogue for when the game's getting long
            Dialogue = random.randint(0,5)
            if Dialogue == 0:
                print("CPU: Wow we're taking our sweet time here aren't we??")
            elif Dialogue == 1:
                print("CPU: Hey can I borrow your assignment after this?? For reference of course...")
            elif Dialogue == 2:
                print("CPU: Used me gut feelings for this!!")
            elif Dialogue == 3:
                print("CPU: Well I'm not winning anytime soon...")
            elif Dialogue == 4:
                print("CPU: Jeez I thought you're better than me...")
            elif Dialogue == 5:
                print("CPU: Still at it!!")
        print(f"{space}")

        Turncount += 1
        turn = False  # Switches to checking win conditions

    # Check for win conditions
    while not turn:
        if EasyPlayerIndex.count('XX') == len(EasyPlayerIndex) and CPUIndex.count('XX') == len(CPUIndex): # For if a draw occurs
            EasyPlayer_print(EasyPlayerIndex, CPUIndex)
            GameOver_print()
            print("\n                               I uhhhh... huh??")
            print(f"                                   It took {Turncount} turns for this draw")
        elif EasyPlayerIndex.count('XX') == len(EasyPlayerIndex): # For if the player wins first
            EasyPlayer_print(EasyPlayerIndex, CPUIndex)
            GameOver_print()
            print("\n                               Hey, YOU WON!! Maybe you should try the hard mode!!")
            print(f"                                   You've taken {Turncount} turns")
            win = True
            sys.exit()  # Exit the game
        elif CPUIndex.count('XX') == len(CPUIndex): # For if the CPU wins first
            EasyPlayer_print(EasyPlayerIndex, CPUIndex)
            GameOver_print()
            print("\n                               Huh, and I was randomly picking...")
            print(f"                                   I've defeated you in {Turncount} turns")
            win = True
            sys.exit()  # Exit the game
        turn = True  # Switches back to inputting
