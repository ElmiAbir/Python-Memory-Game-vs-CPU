import time
difficulty_decoration_prompt = [r"                                         ___ ___ _   ___ ___ _____    ___   ___ ___ ___ ___ ___ _  _ _  _____ _   _  ", 
                                r"                                         [__ |__ |   |__ |     |       |  \  |  |__ |__  |  |   |  | |    |    \_/  o", 
                                r"                                         ___]|__ |__ |__ |__   |      _|__| _|_ |   |   _|_ |__ |__| |__  |     |   o"]
difficulty_decoration_EasyChoice = [r"                                                                  o \ ____ ____ ____ _   _",
                                    r"                                                                  | | |___ |__| [__   \_/ ",
                                    r"                                                                  | / |___ |  | ___]   |  "]
difficulty_decoration_HardChoice = [r"                                                                 oo \ _  _   ____   ____   ___ ",
                                    r"                                                                 || | |__|   |__|   |__/   |  |",
                                    r"                                                                 || / |  |   |  |   |  \   |__/"]
# Print the initial prompt with a slight delay for effect
for line in difficulty_decoration_prompt:
    print(line)
    time.sleep(0.1)
# Print the display for easy choice
for line in difficulty_decoration_EasyChoice:
    print(line)
# Print the display for hard choice
for line in difficulty_decoration_HardChoice:
    print(line)
# Loop until the user selects a valid difficulty mode
while True:
    print("                                               Please type 1 to play on Easy Mode or type 2 to play on Hard Mode")
    Human_Choice = input("                                                                              ")
    # Check if the user chose Easy Mode
    if Human_Choice == "1":
        print("You have chosen Easy Mode. The board on the left is Player Board!")
        # Activate easy mode
        import Easy.py
        # Exit the loop after valid choice
        break
    # Check if the user chose Hard Mode
    elif Human_Choice == "2":
        print("You have chosen Hard Mode. The board on the left is Player Board")
        # Activate hard mode
        import Hard.py
        # Exit the loop after valid choice
        break
    # Handle invalid input
    else:
        print("                                                             Invalid input. Please select 1 or 2.")
